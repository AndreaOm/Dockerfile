var express = require('express')
var cookieParser = require('cookie-parser')
var escape = require('escape-html');
var serialize = require('node-serialize')
var path = require('path')
var bodyParser = require("body-parser")
var app = express()

app.use(cookieParser())
app.use(bodyParser.json())
//app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static(path.join(__dirname,'public')))
app.set('views','./views')
app.set('view engine','jade')
app.locals.pretty = true


app.get('/', function(req, res) {
  if(req.cookies.profile) {
    res.render('index0')
  }
  else {
    res.render('index')
  }
})

app.get('/login', function (req, res) {
  if(req.cookies.profile) {
    return res.redirect('/dashboard')
  }
  res.render('login')
})

app.get('/about', function(req, res) {
  if(req.cookies.profile) {
    res.render('about0')
  }
  else {
    res.render('about')
  }
})

app.get('/logout', function (req, res) {
    res.clearCookie('profile')
    res.redirect('/')
})

app.get('/dashboard',function (req, res) {
  if(req.cookies.profile) {
    var str = new Buffer(req.cookies.profile, 'base64').toString()
    var obj = serialize.unserialize(str)
    res.render('dashboard',{
        username : escape(obj.username)
    })
  }
  else {
    res.redirect('/login')
  }
})


// 创建 application/x-www-form-urlencoded 编码解析
var urlencodedParser = bodyParser.urlencoded({extended: false})

app.post('/login', urlencodedParser, function (req, res) {
    profile = {
        username: req.body.username,
        password: req.body.password
    }
    res.cookie('profile', new Buffer(JSON.stringify(profile)).toString('base64'), {
       maxAge: 900000,
       httpOnly: true
    })
    res.redirect('/dashboard')
})



var server = app.listen(80, function() {
    var host = server.address().address
    var port = server.address().port
    console.log("Server Started, URL: http://%s:%s/", host, port)
})
